<?php require('onepage.php') ?>
<!DOCTYPE html>
<html lang="ru-RU">
<head>
 <title>X-COP 9100s - гибрид радар-детектор + видеорегистратор</title>

    <script src=" https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta name="description" content="Автомобильный видеорегистратор Neoline X-COP 9100s – уникальное комбо-устройство, в котором внедрена технология максимального распознания радаров К, Ка и М диапазона.">
	<link rel="icon" type="image/png" href="favicon.png">
	<link rel="stylesheet" href="assets_pages/land/css/reset.css">
	<link rel="stylesheet" href="assets_pages/land/fonts/Montserrat/Montserrat.css">
	<link rel="stylesheet" href="assets_pages/land/js/slider/owlCarousel-2.2.1/owl.carousel.min.css">
	<link rel="stylesheet" href="css/styles.css">
<meta property="og:type" content="article"/>
<meta property="og:title" content=""/>
<meta property="og:description" content=""/>

</head>
<body>
	<section class="top_line">
		<div class="wrapper clearfix">
			<img src="images/logo.png" alt="" class="logo">
			<ul>
				<li>Быстрая доставка</li>
				<li>Гарантия качества</li>
				<li>Оплата при получении</li>
			</ul>
		</div>
	</section>
	<section class="offer_section">
		<div class="wrapper">
			<h1 class="main_title">X-COP 9100s</h1>
			<h2 class="main_subtitle"><p>Гибрид радар-детектор</p> <span><u>+</u> видеорегистратор</span></h2>
			<ul class="ofr_bull">
				<li><b>Встроенная база радаров</b> и камер со всего мира</li>
				<li><b>Угол обзора 135 градусов</b> В кадр попадает четыре полосы дороги и обочина</li>
				<li><b>Подходит для любого автомобиля</b> Простая установка за 60 секунд</li>
			</ul>
			<div class="sale">Скидка <span>75%</span></div>
			<div class="action_info clearfix">
				<div class="price clearfix">
					<div class="old">
						Обычная цена:
						<p><span><?= $oldPriceHtml ?> </span><small><?= $currencyDisplayHtml ?></small></p>
					</div>
					<div class="new">
						Цена сегодня
						<p><span><?= $newPriceHtml ?> </span><small><?= $currencyDisplayHtml ?></small></p>
					</div>
				</div>
				<div class="timer">
					<p>До конца акции осталось</p>
					<div class="timer_container">
						<div class="timer_block">
							<div class="count hours"></div>
							<div class="text">Часов</div>
						</div>
						<div class="timer_block">
							<div class="count minutes"></div>
							<div class="text">Минут</div>
						</div>
						<div class="timer_block">
							<div class="count seconds"></div>
							<div class="text">Секунд</div>
						</div>
					</div>
				</div>
				<div class="prod_count">
					<p>Осталось на складе</p>
					<span>13<small>шт.</small></span>
				</div>
			</div>
		</div>
	</section>
	<section class="sect_form">
		<div class="wrapper">
			<form class="main-order-form m1-form" action="" method="post" >
			 <?= countrySelect() ?>    
				<input type="text" name="name" placeholder="Введите ваше имя" required="">
				<input type="tel" name="phone" placeholder="Введите ваш телефон" required="">
				<button class="button-m">Заказать сейчас</button>

</form>
		</div>
	</section>
	<section class="sect2">
		<div class="wrapper">
			<ul class="benef1">
				<li>
					<img src="images/benef1_img1.png" alt="">
					<p>Детектирование неуловимого Multa Radar CD/CT</p>
				</li>
				<li>
					<img src="images/benef1_img2.png" alt="">
					<p>Голосовое оповещение о 45 типах радаров</p>
				</li>
				<li>
					<img src="images/benef1_img3.png" alt="">
					<p>Умная технология управления жестами</p>
				</li>
				<li>
					<img src="images/benef1_img4.png" alt="">
					<p>Автоматический переход в режим парковки</p>
				</li>
			</ul>
		</div>
	</section>
	<section class="sect3">
		<div class="wrapper">
			<h2 class="title white">Лучшее качество записи и больше функциональных возможностей</h2>
			<p>Автомобильный видеорегистратор Neoline X-COP 9100s – уникальное комбо-устройство, в котором внедрена технология максимального распознания радаров К, Ка и М диапазона. Среди основных функций устройства также стоит отметить наличие парковочного режима, отличного качества съемки в любое время суток, а также Z сигнатур фильтр.</p>
			<ul class="benef2">
				<li>
                    <iframe width="100%" height="260" src="https://www.youtube.com/embed/ov_rmHnEqoo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					<span>Обнаружение камер</span>
					<p>В гибрид интегрирован фирменный сверхчувствительный модуль нового поколения EXD Plus, который обеспечивает максимальную дистанцию обнаружения полицейских радаров в диапазонах К, Ка и М.</p>
				</li>
				<li>
                    <iframe width="100%" height="260" src="https://www.youtube.com/embed/FEAft_g3wQ0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					<span>Управление жестами</span>
					<p>Если водитель желает отключить звуковое и голосовое предупреждение при приближении к радару, достаточно провести рукой перед экраном гибрида. Фирменная технология Motion Control реагирует на жесты.</p>
				</li>
			</ul>
		</div>
	</section>
	<section class="panorama_sect">
		<img src="images/panorama.jpg" alt="" class="panorama" width="2392" height="277">
	</section>
	<section class="sect4">
		<div class="wrapper">
			<h2 class="title">GPS база всего мира</h2>
			<p class="subtitle">Видеорегистратор Neoline X-COP 9100s избавит вас от проблем на дороге, обеспечит максимальную защиту и сохранит ваш кошелек от нежеланных штрафов!</p>
			<div class="view_angle clearfix">
				<img src="images/desc_img.jpg" alt="">
				<div class="angle_text">
					Впервые в гибрид Neoline встроена база радаров и камер со всего мира (Россия, СНГ, Европа, США, Израиль, Ближний Восток, Турция, Австралия и др.). База включает данные о более чем сотне тысяч радаров. Обновление происходит еженедельно. В гибрид встроен GPS и ГЛОНАСС модули для максимально быстрого и точного геопозиционирования.
				</div>
			</div>
			<a href="#order_form" class="button-m">Заказать со скидкой</a>
		</div>
	</section>
	<section class="sect5">
		<div class="wrapper clearfix">
			<img src="images/1.gif" alt="">
			<div class="text">
				<h2 class="title">Режим день/ночь</h2>
				<p>Широкоугольная оптическая система из <b>6 линз</b> высокого разрешения дает Вам невероятно четкое изображение формата <b>Full HD 1920х1080p,</b> а их повышенная светопропускаемость позволяет фиксировать все происходящее даже в ночное время суток.</p>
			</div>
		</div>
	</section>
	<section class="sect6">
		<div class="wrapper">
			<h2 class="title">Дополнительные функции радар-детектора</h2>
			<div class="add_functions clearfix">
				<div class="left">
					<ul class="benef3">
						<li>
							<img src="images/add_func1.jpg" alt="">
							<div class="text">
								<span>Уникальный модуль exd plus</span>
								<p>Обеспечивает максимальную дистанцию обнаружения полицейских радаров в диапазонах К, Ка и М.</p>
							</div>
						</li>
						<li>
							<img src="images/add_func2.jpg" alt="">
							<div class="text">
								<span>Детектирование multaradar cd/ct</span>
								<p>Neoline X-COP 9100s – это первый в мире гибрид, который детектирует комплексы MultaRadar CD и CT.</p>
							</div>
						</li>
						<li>
							<img src="images/add_func3.jpg" alt="">
							<div class="text">
								<span>Отключение радарного модуля</span>
								<p>Радарный блок может быть легко отключен простым движением руки и устройство продолжит работу в виде GPS информатора.</p>
							</div>
						</li>
						<li>
							<img src="images/add_func4.jpg" alt="">
							<div class="text">
								<span>Голосовое оповещение</span>
								<p>Neoline X-COP 9100s оповестит о типе полицейского радара, разрешенной скорости на участке дороги, выдаст информацию о расстоянии к радару и средней скорости .</p>
							</div>
						</li>
						<li>
							<img src="images/add_func5.jpg" alt="">
							<div class="text">
								<span>Включение отдельных типов точек gps</span>
								<p>Гибкость настроек позволяет включать и выключать отдельные точки GPS, такие как: посты ДПС, камеры системы «Автодория», стационарные радары «Стрелка», муляжи радарных комплексов и др.</p>
							</div>
						</li>
						<li>
							<img src="images/add_func6.jpg" alt="">
							<div class="text">
								<span>Дальность gps оповещений</span>
								<p>Дальность оповещений к полицейским радарам в базе GPS может быть установлена исходя из ваших предпочтений</p>
							</div>
						</li>
					</ul>
				</div>
				<div class="right">
					<p class="type_radar">Типы полицейских радаров и камер</p>
					<ul class="benef4">
						<li>
							<div class="img"><img src="images/radar1.jpg" alt=""></div>
							<p><b>Новейшие маломощные радары Multa - диапазон M</b> MultaRadar CD, CT, CD moving</p>
						</li>
						<li>
							<div class="img"><img src="images/radar2.jpg" alt=""></div>
							<p><b>Европейские радары - диапазон Ka</b> Ramer, Multanova 6F, Stalker и др.</p>
						</li>
						<li>
							<div class="img"><img src="images/radar3.jpg" alt=""></div>
							<p><b>Контроль мгновенной и средней скорости</b> Кордон-Темп, Скат-Риф, Стрелка Плюс, Автоураган-ВСМ, Вокорд, Циклоп и др.</p>
						</li>
						<li>
							<div class="img"><img src="images/radar4.jpg" alt=""></div>
							<p><b>Контроль средней скорости</b> Автодория, Стрелка-Плюс и др.</p>
						</li>
						<li>
							<div class="img"><img src="images/radar5.jpg" alt=""></div>
							<p><b>Мобильная засада ДПС</b> Скат, Оскон, Кордон, Крис, Арена, Полискан и др.</p>
						</li>
						<li>
							<div class="img"><img src="images/radar6.jpg" alt=""></div>
							<p><b>Маломощные радары</b> Кордон, робот, Арена, Кречет, Gatso, Mesta и др.</p>
						</li>
						<li>
							<div class="img"><img src="images/radar7.jpg" alt=""></div>
							<p><b>Лазерные измерители скорости</b> Полискан, Амата и др.</p>
						</li>
						<li>
							<div class="img"><img src="images/radar8.jpg" alt=""></div>
							<p><b>Стрелка</b> Стрелка-СТ, Стрелка-Плюс, Стрелка-М</p>
						</li>
						<li>
							<div class="img"><img src="images/radar9.jpg" alt=""></div>
							<p><b>Безрадарные комплексы</b> Автоураган-ВС, Вокорд-Трафик, Стрит Фалькон, Стрелка Видеоблок, Птолемей, Интегра КДД и др.</p>
						</li>
					</ul>
				</div>
			</div>
			<a href="#order_form" class="button-m">Оформить заказ</a>
		</div>
	</section>
	<section class="sect5 ver2">
		<div class="wrapper clearfix">
			<img src="images/hidden.jpg" alt="">
			<div class="text">
				<h2 class="title">Практически незаметен снаружи</h2>
				<p>Расположив гибрид у верхнего края лобового стекла, вы сделаете его практически незаметным снаружи. При этом провод питания подключается непосредственно в компактное крепление с активной зарядкой на 3М скотче Smart Click Plus. Данное решение позволяет убрать любые вибрации при движении по грунтовой дороге.</p>
			</div>
		</div>
	</section>
	<section class="sect8">
		<div class="wrapper">
			<div class="content clearfix">
				<div class="equip_set">
					<h2 class="title">Комплектация</h2>
					<img src="images/set.jpg" alt="">
					<ul class="list1">
						<li>1. Крепление с активной зарядкой на 3М скотче Smart Click Plus</li>
						<li>2. Кабель питания в автомобильную розетку (DC12В ~ 24В)</li>
						<li>3. Кабель питания к бортовой сети Neoline Fuse Cord 3 pin (DC12В ~ 24В)</li>
						<li>4. Крепежные элементы для кабеля питания (8 шт)</li>
						<li>5. Запасной 3М скотч</li>
						<li>6. Кейс для хранения</li>
						<li>7. Инструмент для снятия 3М скотча</li>
					</ul>
				</div>
				<div class="char_block">
					<h2 class="title">Характеристики</h2>
					<ul class="char_list">
						<li><b>Тип матрицы:</b> CMOS</li>
						<li><b>Качество видеосъемки:</b> Full HD (1920x1080 Пикс)</li>
						<li><b>Макс. частота кадров:</b> 30 кадр/сек</li>
						<li><b>Угол обзора (основная камера):</b> 135 градусов</li>
						<li><b>Макс. разреш. фотосъемки:</b> 2560x1920 Пикс</li>
						<li><b>Диагональ дисплея:</b> 2"/ 5.1 см</li>
						<li><b>Разрешение дисплея:</b> 240 x 320 Пикс</li>
						<li><b>Сенсорный дисплей:</b> Да</li>
						<li><b>Поддерживаемые карты памяти:</b> microSD, microSDHC, microSDXC</li>
						<li><b>Макс. емкость карты памяти:</b> 128 ГБ</li>
						<li><b>Режим ночной съемки:</b> Да</li>
						<li><b>Режим аварийной записи:</b> Да</li>
						<li><b>Интервал записи:</b> 1/2/3/5 мин.</li>
						<li><b>Циклическая запись:</b> Да</li>
						<li><b>Датчик движения:</b> Да</li>
						<li><b>G-сенсор (датчик удара):</b> Да</li>
						<li><b>Цвет:</b> черный</li>
						<li><b>Габаритные размеры (В*Ш*Г):</b> 94*73*46 мм</li>
						<li><b>Вес:</b> 280 г</li>
					</ul>
				</div>
			</div>
			<a href="#order_form" class="button-m">Заказать со скидкой</a>
		</div>
	</section>
	<section class="sect9">
		<div class="wrapper">
			<h2 class="title white">Отзывы автовладельцев</h2>
			<div class="reviews owl-carousel">
				<div class="rev_item">
					<img src="images/rev1.jpg" alt="">
					<span>Отличная вещь по доступной цене</span>
					<p><span>Я долго ждал подобной новинки, поскольку надоело плохое качество изображения в моем регистраторе. Заказал, решил опробовать, все понравилось. Компактные размеры, качество Full HD, шикарный угол обзора, сенсорный дисплей. Я не ошибся в выборе, хочу заказать еще такой брату.</span></p>
					<div class="author clearfix">
						<img src="images/ava1.jpg" alt="">
						<p>Морозов Игорь</p>
					</div>
				</div>
				<div class="rev_item">
					<img src="images/rev2.jpg" alt="">
					<span>Качество с доставкой!</span>
					<p><span>Авто-регистратор с детектором радаров. Несмотря на универсальность - интерфейс не перегружен, управление удобное. Классно организовано крепление, со сквозным питанием. Не страдает разъем питания. Есть второй разъем под карту памяти для копирования роликов</span></p>
					<div class="author clearfix">
						<img src="images/ava2.jpg" alt="">
						<p>Молчанов Эрик</p>
					</div>
				</div>
				<div class="rev_item">
					<img src="images/rev3.jpg" alt="">
					<span>Все функции в одном устройстве</span>
					<p><span>Регистратор с детектором радаров, также встроен спидкам (хорошие базы и часто обновляются). Все управляется через понятный интерфейс, разберется любой. Небольшой корпус и экран, но управление удобное, видно, что постарались при написании софта. </span></p>
					<div class="author clearfix">
						<img src="images/ava3.jpg" alt="">
						<p>Скляренко Вадим</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="sect10">
		<div class="wrapper">
			<h2 class="title">Доставка и оплата</h2>
			<ul class="benef1">
				<li>
					<img src="images/order1.png" alt="">
					<p>Оставляете заявку на нашем сайте</p>
				</li>
				<li>
					<img src="images/order2.png" alt="">
					<p>Наш менеджер уточняет детали заказа</p>
				</li>
				<li>
					<img src="images/order3.png" alt="">
					<p>Доставляем ваш товар в течение 3‑10 дней</p>
				</li>
				<li>
					<img src="images/order4.png" alt="">
					<p>Оплачиваете при получении на почте</p>
				</li>
			</ul>
		</div>
	</section>
	<section class="offer_section bottom">
		<div class="wrapper">
			<h1 class="main_title">Гибрид радар-детектор X-COP 9100s</h1>
			<h2 class="main_subtitle"><p>Оставьте заявку сейчас</p> <span>и получите скидку <span>-75%</span></span></h2>
			<div class="price clearfix">
				<div class="old">
					Обычная цена:
					<p><span><?= $oldPriceHtml ?> </span><small><?= $currencyDisplayHtml ?></small></p>
				</div>
				<div class="new">
					Цена сегодня
					<p><span><?= $newPriceHtml ?> </span><small><?= $currencyDisplayHtml ?></small></p>
				</div>
			</div>
			<div class="formbox">
				<div class="timer">
					<p>До конца акции осталось</p>
					<div class="timer_container">
						<div class="timer_block">
							<div class="count hours"></div>
							<div class="text">Часов</div>
						</div>
						<div class="timer_block">
							<div class="count minutes"></div>
							<div class="text">Минут</div>
						</div>
						<div class="timer_block">
							<div class="count seconds"></div>
							<div class="text">Секунд</div>
						</div>
					</div>
				</div>
				<form id="order_form" class="main-order-form m1-form" action="" method="post" >
				 <?= countrySelect() ?>    
					<input type="text" name="name" placeholder="Введите ваше имя" required="">
					<input type="tel" name="phone" placeholder="Введите ваш телефон" required="">
					<button class="button-m" >Заказать сейчас</button>

</form>
			</div>
		</div>
	</section>
	<footer class="footer_section">
		<div class="wrapper">
<?= footer() ?>
		</div>
	</footer>

<style>
.form-control{
	padding-left: 10px;
	border: none;
	background: #fafafa;
	width: 300px;
	height: 52px;
	font-size: 16px;
	font-family: 'Montserrat', Arial, Helvetica, sans-serif;
	color: black;
	border-radius: 26px;
	margin-bottom: 20px;
	text-align: center;
}
</style>

	<script src="assets_pages/land/js/slider/owlCarousel-2.2.1/owl.carousel.min.js"></script>
	<script src="js/jquery.panorama.js"></script>
	<script src="js/scripts.js"></script>
	<!-- /scripts -->
</body>
</html>