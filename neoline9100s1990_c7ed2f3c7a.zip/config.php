<?php

$apiKey = 'XvTDZO5wt4yQycBzzKCIGKIVrbuSh1zaEkoL66cMS1COLnCShnItdOj';          // Ключ доступа к API
$offer_id = 2884;         // для каждого оффера свой айди, надо уточнять его в админке или у суппортов
$stream_hid = 'r86tb4Ek';     // id потока

$default_main_site = 'http://api.cpa.tl';
$apiSendLeadUrl = 'http://api.cpa.tl/api/lead/send_archive';
$apiGetLeadUrl = 'http://api.cpa.tl/api/lead/feed';

$dataOffers = '{"16384":{"currency":{"name":"\u0440\u0443\u0431","code":"RUB"},"id":16384,"price":"1990","country":{"name":"\u0420\u043e\u0441\u0441\u0438\u044f","code":"RU"},"name":"\u0412\u0438\u0434\u0435\u043e\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440 Neoline X-COP 9100S","price2":"7960"}}';
$dataOffer = '{"currency":{"name":"\u0440\u0443\u0431","code":"RUB"},"id":16384,"price":"1990","country":{"name":"\u0420\u043e\u0441\u0441\u0438\u044f","code":"RU"},"name":"\u0412\u0438\u0434\u0435\u043e\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440 Neoline X-COP 9100S","price2":"7960"}';
$productName = 'Видеорегистратор Neoline X-COP 9100S';
$invoice = 'index.php';
$push_link = '';
$language = 'ru';
$companyInfo = array('address' => '108811, ГОРОД МОСКВА, КИЛОМЕТР КИЕВСКОЕ ШОССЕ 22-Й (П МОСКОВСКИЙ), ДОМОВЛАД. 4, КОРПУС Е СТР 5, БЛОК 502Е ЭТ 5 ОФ 15', 'detail' => 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ "ТОРГОВЛЯ" ОГРН: 5177746360985 ИНН: 9701097075 КПП: 775101001');

if(!$apiKey){
    echo 'Ключ доступа к API не определен. Получите в личном кабинете или обратитесь в службу поддержки';
    die;
}

if(!$offer_id){
    echo 'ID оффера не определен';
    die;
}
